Plots histogram of random data using Matplotlib. 
