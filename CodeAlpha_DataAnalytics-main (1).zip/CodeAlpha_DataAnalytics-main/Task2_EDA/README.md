# Task 2: EDA 
Uses Pandas and Seaborn to analyze Titanic dataset. 
Uses Pandas and Seaborn to analyze Titanic dataset. 
