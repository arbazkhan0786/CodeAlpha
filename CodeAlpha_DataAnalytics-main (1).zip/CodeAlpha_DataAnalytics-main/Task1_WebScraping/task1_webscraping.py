print("Hello from Web Scraping Task") 
