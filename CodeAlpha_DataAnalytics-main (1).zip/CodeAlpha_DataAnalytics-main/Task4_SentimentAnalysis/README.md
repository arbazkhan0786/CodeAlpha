Classifies text sentiment as Positive, Negative, or Neutral. 
